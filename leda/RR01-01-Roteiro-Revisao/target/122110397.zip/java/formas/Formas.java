package formas;

public interface Formas {
    
    public double area();
}
